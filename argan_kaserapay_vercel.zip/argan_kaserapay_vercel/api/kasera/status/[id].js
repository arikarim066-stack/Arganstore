const baseUrl = () => (process.env.KASERA_BASE_URL || 'https://pay.kasera.id').replace(/\/$/, '');

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.KASERA_API_KEY;
  if (!key) return res.status(500).json({ error: 'KASERA_API_KEY belum diatur di Vercel Environment Variables.' });

  try {
    const id = req.query?.id;
    if (!id) return res.status(400).json({ error: 'Transaction ID wajib diisi' });
    const response = await fetch(`${baseUrl()}/v1/transactions/${encodeURIComponent(id)}`, {
      headers: { Authorization: `Bearer ${key}` }
    });
    const data = await response.json().catch(() => ({}));
    return res.status(response.status).json(data);
  } catch (error) {
    return res.status(500).json({ error: error?.message || 'Server error' });
  }
}
