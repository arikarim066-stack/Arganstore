const baseUrl = () => (process.env.KASERA_BASE_URL || 'https://pay.kasera.id').replace(/\/$/, '');

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.KASERA_API_KEY;
  if (!key) return res.status(500).json({ error: 'KASERA_API_KEY belum diatur di Vercel Environment Variables.' });

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    if (!body.external_id || !Number.isInteger(Number(body.amount)) || Number(body.amount) <= 0) {
      return res.status(400).json({ error: 'external_id dan amount wajib valid' });
    }

    const payload = {
      amount: Number(body.amount),
      description: body.description || body.external_id,
      external_id: body.external_id,
      merchant_ref: body.merchant_ref || body.external_id,
      customer: body.customer || undefined,
      order_items: body.order_items || undefined,
      payment_methods: Array.isArray(body.payment_methods) && body.payment_methods.length ? body.payment_methods : undefined,
      return_url: body.return_url || undefined,
      expires_in_minutes: Number(body.expires_in_minutes || 60)
    };
    Object.keys(payload).forEach(k => payload[k] === undefined && delete payload[k]);

    const response = await fetch(`${baseUrl()}/v1/transactions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${key}`,
        'Idempotency-Key': String(body.external_id),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.message || data?.error || 'Kasera Pay menolak transaksi',
        details: data
      });
    }
    return res.status(201).json(data);
  } catch (error) {
    return res.status(500).json({ error: error?.message || 'Server error' });
  }
}
