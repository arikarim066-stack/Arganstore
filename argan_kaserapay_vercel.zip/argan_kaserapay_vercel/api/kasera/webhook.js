import crypto from 'node:crypto';

export const config = { api: { bodyParser: false } };

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method not allowed');
  const secret = process.env.KASERA_WEBHOOK_SECRET;
  if (!secret) return res.status(500).send('KASERA_WEBHOOK_SECRET belum diatur');

  try {
    const rawBody = await readRawBody(req);
    const signature = req.headers['kasera-signature-v1'] || '';
    const sig = Array.isArray(signature) ? signature[0] : signature;
    const tm = String(sig).match(/(?:^|,)t=(\d+)(?:,|$)/);
    const vm = String(sig).match(/(?:^|,)v1=([a-f0-9]+)(?:,|$)/i);
    if (!tm || !vm) return res.status(400).send('Bad signature');

    const timestamp = Number(tm[1]);
    if (Math.abs(Date.now() / 1000 - timestamp) > 300) return res.status(400).send('Stale signature');

    const expected = crypto.createHmac('sha256', secret).update(`${timestamp}.${rawBody.toString('utf8')}`).digest('hex');
    const expectedBuf = Buffer.from(expected, 'hex');
    const receivedBuf = Buffer.from(vm[1], 'hex');
    if (expectedBuf.length !== receivedBuf.length || !crypto.timingSafeEqual(expectedBuf, receivedBuf)) {
      return res.status(400).send('Bad signature');
    }

    const event = JSON.parse(rawBody.toString('utf8'));
    // Acknowledge only after signature verification. Fulfillment can be connected to a database next.
    return res.status(200).json({ ok: true, event_id: event?.id || null });
  } catch {
    return res.status(400).send('Invalid webhook');
  }
}
