export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ ok: false, error: 'Method not allowed' });
  const key = process.env.KASERA_API_KEY || '';
  return res.status(200).json({
    ok: true,
    provider: 'kasera-pay',
    configured: Boolean(key),
    environment: key.startsWith('kp_live_') ? 'live' : key.startsWith('kp_test_') ? 'test' : 'unknown'
  });
}
