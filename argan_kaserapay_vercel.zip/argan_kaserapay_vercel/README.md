# Argan Store + Kasera Pay — Vercel

This package makes the Kasera Pay backend available as Vercel Functions while keeping the live API key out of the HTML.

## Vercel Environment Variables

Add these in Project Settings → Environment Variables:

- `KASERA_API_KEY` = your Kasera live/test API key
- `KASERA_BASE_URL` = `https://pay.kasera.id`
- `KASERA_WEBHOOK_SECRET` = your Kasera webhook secret (needed before enabling the webhook)

Use Production for the live deployment.

## API routes

- `GET /api/kasera/health`
- `POST /api/kasera/create-payment`
- `GET /api/kasera/status/:id`
- `POST /api/kasera/webhook`

## Deploy

Upload this folder as the Vercel project source, or connect it to a Git repository, then redeploy.

The static store is `index.html`; Vercel automatically exposes files under `api/` as serverless functions.
